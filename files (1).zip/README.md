# Westermo EdgePredict
### Industrial Wireless Network — Edge AI Anomaly Detection

A production-ready prototype demonstrating real-time anomaly detection for industrial wireless devices using FastAPI + Isolation Forest + WebSocket live streaming.

---

## Architecture

```
frontend/index.html          ← Dashboard UI (zero dependencies, runs in any browser)
backend/main.py              ← FastAPI server
  ├── POST /predict          ← Single reading inference
  ├── GET  /events           ← Historical log
  ├── GET  /stats            ← Aggregated stats
  ├── GET  /model/info       ← Model metadata
  └── WS   /ws/live          ← Real-time simulation stream + fault injection
```

## Quick Start

### 1. Install dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 2. Start the API server
```bash
uvicorn main:app --reload --port 8000
```

Server runs at: http://localhost:8000  
API docs at:    http://localhost:8000/docs

### 3. Open the dashboard
```bash
open frontend/index.html
# or just double-click it in your file manager
```

The dashboard auto-connects to the WebSocket. If the server isn't running, it falls back to **demo mode** (client-side simulation) automatically — useful for offline demos.

---

## Key Features

| Feature | Details |
|---|---|
| **ML Model** | Isolation Forest, 100 estimators, 5% contamination, trained on 2,000 samples |
| **Features** | Signal strength (dBm), Packet loss (%), Temperature (°C), Latency (ms) |
| **Streaming** | WebSocket pushes 4 device readings every second |
| **Fault injection** | Trigger packet loss, temperature runaway, or signal deterioration on any device via UI or API |
| **Severity levels** | normal / warning / critical based on anomaly score threshold |
| **Demo mode** | Works offline with client-side Gaussian simulation |

---

## API Usage Examples

```bash
# Single prediction
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"device_id":"WES-3152P-A","signal_strength":-70,"packet_loss":8.5,"temperature":50,"latency":15}'

# Response:
# {"device_id":"WES-3152P-A","is_anomaly":true,"severity":"critical","anomaly_score":-0.1823,...}

# Live stats
curl http://localhost:8000/stats

# Last 50 anomalies only
curl "http://localhost:8000/events?anomalies_only=true&limit=50"
```

---

## Fault Injection via WebSocket

Connect to `ws://localhost:8000/ws/live` and send JSON control messages:

```json
{ "action": "inject_fault", "device": "WES-3152P-B", "fault_type": "packet_loss" }
{ "action": "inject_fault", "device": "WES-3152P-C", "fault_type": "temperature" }
{ "action": "inject_fault", "device": "WES-4960G-A", "fault_type": "signal" }
{ "action": "clear_fault" }
```

---

## Interview Talking Points

> *"The Isolation Forest model trains on 2,000 samples of normal device behaviour. Once deployed to an edge device, it needs no labels — it learns what 'normal' looks like and flags deviations in under 1ms per inference. The WebSocket stream lets an operator see all four devices in real-time and inject simulated faults to test the detection pipeline live."*

**Why Isolation Forest for edge AI?**
- Lightweight: ~200KB serialised model
- Unsupervised: no labelled fault data needed
- Fast inference: O(log n) per sample
- Interpretable score: negative values = more anomalous

---

## Project Structure

```
edgepredict/
├── backend/
│   ├── main.py              ← FastAPI app + ML model + WebSocket
│   └── requirements.txt
├── frontend/
│   └── index.html           ← Self-contained dashboard
└── README.md
```
